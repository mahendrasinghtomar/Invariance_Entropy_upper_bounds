#include <stdio.h>

void classify(const state_type &X, input_type &u, int &Ain) {
	{{code}}