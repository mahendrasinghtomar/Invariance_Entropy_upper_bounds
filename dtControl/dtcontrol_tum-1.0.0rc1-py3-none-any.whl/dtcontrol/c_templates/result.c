#include <stdio.h>

void classify(const float X[], float result[]);

int main() {
    float X[] = {1.2, 3.2, -1.2};
    float result[2];
    classify(X, result);
    return 0;
}

void classify(const float X[], float result[]) {
    outputs[0] = 1.2; outputs[1] = 4.5; return;
}